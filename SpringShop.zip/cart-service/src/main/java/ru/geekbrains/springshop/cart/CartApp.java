package ru.geekbrains.springshop.cart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartApp {
	public static void main(String[] args) {
		SpringApplication.run(CartApp.class, args);
	}
}

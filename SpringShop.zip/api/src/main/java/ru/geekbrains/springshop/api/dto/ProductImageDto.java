package ru.geekbrains.springshop.api.dto;

public class ProductImageDto {
	private String imagePath;

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public ProductImageDto() {
	}
}

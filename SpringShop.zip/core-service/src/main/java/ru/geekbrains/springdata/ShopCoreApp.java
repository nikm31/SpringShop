package ru.geekbrains.springdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopCoreApp {
    public static void main(String[] args) {
        SpringApplication.run(ShopCoreApp.class, args);
    }

}

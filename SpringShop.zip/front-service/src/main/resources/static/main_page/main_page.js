angular.module('store').controller('mainPageController', function ($scope, $http, $localStorage) {

});
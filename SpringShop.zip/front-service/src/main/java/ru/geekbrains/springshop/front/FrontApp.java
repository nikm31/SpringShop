package ru.geekbrains.springshop.front;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontApp {
	public static void main(String[] args) {
		SpringApplication.run(FrontApp.class, args);
	}
}

angular.module('store').controller('cartController', function ($scope, $http, $location, $localStorage) {
    const contextPath = 'http://127.0.0.1:8080/'

    $scope.loadCart = function () {
        let url = contextPath + 'api/v1/cart/' + $localStorage.webMarketGuestCartId
        console.log(url)
            $http.get(url).then(function (response) {
            console.log(response.data)
            $scope.cart = response.data;
        });
    }


    $scope.addToCart = function (productId) {
        let url = contextPath + 'api/v1/cart/' + $localStorage.webMarketGuestCartId + '/add/' + productId;
        console.log(url);
        $http.get(url).then(function (response) {
            $scope.loadCart();
        });
    }

    $scope.removeFromCart = function (productId) {
        let url = contextPath + 'api/v1/cart/' + $localStorage.webMarketGuestCartId + '/decrement/' + productId;
        console.log(url);
        $http.get(url).then(function (response) {
            $scope.loadCart();
        });
    }

    $scope.removeProductFromCartList = function (productId) {
        let url = contextPath + 'api/v1/cart/' + $localStorage.webMarketGuestCartId + '/remove/' + productId;
        console.log(url);
        $http.get(url).then(function (response) {
            $scope.loadCart();
        });
    }

    $scope.loadCart();
});
angular.module('store').controller('addProductController', function ($scope, $http, $location) {
    const contextPath = 'http://localhost:8080/api/v1/products';

    var mainApp = angular.module('store');

    // $scope.createProduct = function () {
    //     if ($scope.new_product == null) {
    //         alert('Форма не заполнена');
    //         return;
    //     }
    //     $http.post(contextPath + 'api/v1/products', $scope.new_product)
    //         .then(function successCallback(response) {
    //             $scope.new_product = null;
    //             alert('Продукт успешно создан');
    //             $location.path(contextPath + 'api/v1/products/');
    //         }, function failureCallback(response) {
    //             console.log(response);
    //             alert(response.data.messages);
    //         });
    // }

// DIRECTIVE - FILE MODEL
    mainApp.directive('fileModel', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind('change', function () {
                    scope.$apply(function () {
                        modelSetter(scope, element[0].files[0]);
                    });
                });
            }
        };
    }]);


    $scope.uploadResult ="";

    $scope.new_product = {
        title: "",
        price: "",
        categoryTitle: "",
        files: []
    }

    $scope.doUploadFile = function() {


        var data = new FormData();

        data.append("description", $scope.new_product.title);
        data.append("description", $scope.new_product.price);
        data.append("description", $scope.new_product.categoryTitle);
        data.append("files", $scope.new_product.files[0]);

        var config = {
            transformRequest: angular.identity,
            transformResponse: angular.identity,
            headers: {
                'Content-Type': undefined
            }
        }


        $http.post(contextPath, data, config).then(
            // Success
            function(response) {
                $scope.uploadResult =  response.data;
            },
            // Error
            function(response) {
                $scope.uploadResult = response.data;
            });
    };

});
angular.module('store').controller('lostPasswordController', function ($scope, $http) {
    const contextPath = 'http://127.0.0.1:8080/api/v1/recover_password';

    $scope.changePassword = function () {
        $http.put(contextPath, $scope.updatePassword)
            .then(function successCallback (response) {
                alert('Пароль заменен');
            }, function failureCallback (response) {
                alert(response.data.messages);
            });
    }

});
angular.module('store').controller('storeController', function ($scope, $http, $location, $localStorage) {
    const contextPath = 'http://127.0.0.1:8080/'
    let currentPageIndex = 1;

    $scope.showProducts = function (pageIndex = 1) {
        currentPageIndex = pageIndex;
        $http({
            url: contextPath + 'api/v1/products',
            method: 'GET',
            params: {
                page: currentPageIndex,
                pageSize: 5,
                title: $scope.title,
                minPrice: $scope.minPrice,
                maxPrice: $scope.maxPrice
            }
        }).then(function (response) {
            console.log(response);
            $scope.productsPage = response.data;
            $scope.paginationArray = $scope.generatePagesIndexes(1, $scope.productsPage.totalPages);
        })
    }

    $scope.generatePagesIndexes = function (startPage, endPage) {
        let arr = [];
        for (let i = startPage; i < endPage + 1; i++) {
            arr.push(i);
        }
        return arr;
    }

    $scope.deleteProduct = function (productId) {
        let url = contextPath + 'api/v1/products/' + productId;
        console.log(url);
        $http.delete(url)
            .then(function successCallback(response) {
                alert('Продукт успешно удален');
                $scope.showProducts(currentPageIndex);
            }, function failureCallback(response) {
                alert(response.data.messages);
            });
    }

    $scope.addToCart = function (productId) {
        $http({
            url: contextPath + 'api/v1/cart/' + $localStorage.webMarketGuestCartId + '/add/' + productId,
            method: 'GET'
        }).then(function (response) {
        });
    };

    $scope.navToEditProductPage = function (productId) {
        $location.path('/edit_product/' + productId);
    }

    $scope.showProducts();
});
angular.module('store').controller('mainPageController', function ($scope, $http) {
    const contextPath = 'http://localhost:8080/'
});
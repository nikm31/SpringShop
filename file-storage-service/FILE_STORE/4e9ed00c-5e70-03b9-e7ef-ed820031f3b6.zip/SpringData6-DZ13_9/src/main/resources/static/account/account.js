angular.module('store').controller('accountController', function ($scope, $http, $location, $localStorage) {
    const contextPath = 'http://127.0.0.1:8080/api/v1/account';
    $scope.userName = $localStorage.webMarketUser.username;
    $scope.userRoles = $localStorage.webMarketUser.roles;

    $scope.showUserInfo = function () {
    }

    $scope.showUserInfo();
});
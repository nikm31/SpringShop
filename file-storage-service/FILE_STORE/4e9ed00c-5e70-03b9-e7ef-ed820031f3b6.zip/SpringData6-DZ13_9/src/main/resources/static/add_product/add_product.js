angular.module('store').controller('addProductController', function ($scope, $http) {

    $scope.uploadResult = "";

    $scope.myForm = {
        title: "",
        price: "",
        categoryTitle: "",
        file: ""
    }

    $scope.doUploadFile = function () {

        var url = "/api/v1/products";

        var data = new FormData();

        data.append("title", $scope.myForm.title);
        data.append("price", $scope.myForm.price);
        data.append("category", $scope.myForm.categoryTitle);
        data.append("files", $scope.myForm.file);

        var config = {
            transformRequest: angular.identity,
            transformResponse: angular.identity,
            headers: {
                'Content-Type': undefined
            }
        }
        var post = $http.post(url, data, config);

        console.log(post);

      $http.post(url, data, config).then(
            function (response) {
                $scope.uploadResult = response.data;
            },
            function (response) {
                $scope.uploadResult = response.data;
            });
    };

});
package ru.geekbrains.springdata.services;

import org.springframework.stereotype.Service;
import ru.geekbrains.springdata.entity.shop.Category;
import ru.geekbrains.springdata.repositories.shop.CategoryRepo;

import java.util.Optional;

@Service
public class CategoryService {
    private CategoryRepo categoryRepo;

    public CategoryService(CategoryRepo categoryRepo) {
        this.categoryRepo = categoryRepo;
    }

    public Optional<Category> findByTitle(String title){
        return categoryRepo.findByTitle(title);
    }
}

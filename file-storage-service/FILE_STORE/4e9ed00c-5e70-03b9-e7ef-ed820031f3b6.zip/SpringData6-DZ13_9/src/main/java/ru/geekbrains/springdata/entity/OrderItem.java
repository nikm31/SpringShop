package ru.geekbrains.springdata.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import ru.geekbrains.springdata.entity.shop.Product;


@Data
@NoArgsConstructor
public class OrderItem {
    private Long productId;
    private String productTitle;
    private int quantity;
    private int pricePerProduct;
    private int price;

    public OrderItem(Product product) {
        this.productId = product.getId();
        this.productTitle = product.getTitle();
        this.quantity = 1;
        this.price = product.getPrice();
        this.pricePerProduct = product.getPrice();
    }

    public OrderItem(OrderItem orderItem) {
        this.productId = orderItem.getProductId(); //
        this.productTitle = orderItem.getProductTitle();
        this.quantity = orderItem.getQuantity();
        this.price = orderItem.getPrice();
        this.pricePerProduct = orderItem.getPricePerProduct();
    }

    public void changeQuantity(int delta) {
        quantity += delta;
        if (quantity < 0) {
            quantity = 0;
        }
        price = pricePerProduct * quantity;
    }
}

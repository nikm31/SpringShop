package ru.geekbrains.springdata.utils;

import lombok.Data;
import ru.geekbrains.springdata.entity.OrderItem;
import ru.geekbrains.springdata.entity.shop.Product;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Data
public class ShoppingCart {
    private List<OrderItem> items;
    private int totalPrice;

    public ShoppingCart() {
        items = new ArrayList<>();
        totalPrice = 0;
    }

    public boolean add(Long productId) {
        for (OrderItem i : items) {
            if (i.getProductId().equals(productId)) {
                i.changeQuantity(1);
                recalculate();
                return true;
            }
        }
        return false;
    }

    public void add(Product product) {
        items.add(new OrderItem(product));
        recalculate();
    }

    public void decrement(Long productId) {
        Iterator<OrderItem> iter = items.iterator();
        while (iter.hasNext()) {
            OrderItem i = iter.next();
            if (i.getProductId().equals(productId)) {
                i.changeQuantity(-1);
                if (i.getQuantity() <= 0) {
                    iter.remove();
                }
                recalculate();
                return;
            }
        }
    }

    public void remove(Long productId) {
        items.removeIf(i -> i.getProductId().equals(productId));
        recalculate();
    }

    public void clear() {
        items.clear();
        totalPrice = 0;
    }

    private void recalculate() {
        totalPrice = 0;
        for (OrderItem i : items) {
            totalPrice += i.getPrice();
        }
    }

    public void merge(ShoppingCart another) {
        for (OrderItem anotherItem : another.items) {
            boolean merged = false;
            for (OrderItem myItem : items) {
                if (myItem.getProductId().equals(anotherItem.getProductId())) {
                    myItem.changeQuantity(anotherItem.getQuantity());
                    merged = true;
                    break;
                }
            }
            if (!merged) {
                items.add(anotherItem);
            }
        }
        recalculate();
        another.clear();
    }
}
package ru.geekbrains.springdata.entity.files;

import lombok.Data;
import lombok.NoArgsConstructor;
import ru.geekbrains.springdata.entity.users.User;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "file_info_metadata")
@Data
@NoArgsConstructor
public class FileMeta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "hash")
    private UUID hash;

    @Column(name = "filename")
    private String fileName;

    @Column(name = "sub_type")
    private Long subType;

    @Column(name = "user_id")
    private Long userId;
}
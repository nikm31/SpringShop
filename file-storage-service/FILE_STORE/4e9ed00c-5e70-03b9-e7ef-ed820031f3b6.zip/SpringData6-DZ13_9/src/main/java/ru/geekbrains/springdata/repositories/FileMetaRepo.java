package ru.geekbrains.springdata.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import ru.geekbrains.springdata.dto.FileMetaDTO;
import ru.geekbrains.springdata.entity.files.FileMeta;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

@Repository
public interface FileMetaRepo extends JpaRepository<FileMeta, Long> {

    List<FileMeta> findByHashAndUserId(UUID hashName, Long userId);
    List<FileMeta> findByHash(UUID hashName);

    Collection<FileMetaDTO> findBySubType(Long subType);

    FileMeta findByFileNameAndUserId(String fileName, Long userId);

    List<FileMeta> findByHashAndUserIdNot(UUID hash, Long userId);

    @Transactional
    void deleteByHashAndUserId(UUID hash,Long userId);

}


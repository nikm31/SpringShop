package ru.geekbrains.springdata.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@NoArgsConstructor
public class FileMetaDTO {
     private UUID hash;
     private String fileName;
}

package ru.geekbrains.springdata.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.geekbrains.springdata.dto.StringResponse;
import ru.geekbrains.springdata.services.ShoppingCartService;
import ru.geekbrains.springdata.utils.ShoppingCart;

import java.security.Principal;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/cart")
public class CartController {
    @Autowired
    private ShoppingCartService shoppingCartService;

    @GetMapping("/generate")
    public StringResponse generateCartUuid() {
        return new StringResponse(UUID.randomUUID().toString());
    }

    @GetMapping("/{uuid}/merge")
    public void mergeCarts(Principal principal, @PathVariable String uuid) {
        // TODO кто-нибудь может додуматься это вызвать без токена
        shoppingCartService.merge(principal, uuid);
    }

    @GetMapping("/{uuid}")
    public ShoppingCart getCartForCurrentUser(Principal principal, @PathVariable String uuid) {
        return shoppingCartService.getCartForCurrentUser(principal, uuid);
    }

    @GetMapping("/{uuid}/add/{productId}")
    public void addToCart(Principal principal, @PathVariable String uuid, @PathVariable Long productId) {
        shoppingCartService.addItem(principal, uuid, productId);
    }

    @GetMapping("/{uuid}/decrement/{productId}")
    public void decrementItem(Principal principal, @PathVariable String uuid, @PathVariable Long productId) {
        shoppingCartService.decrementItem(principal, uuid, productId);
    }

    @GetMapping("/{uuid}/remove/{productId}")
    public void removeItem(Principal principal, @PathVariable String uuid, @PathVariable Long productId) {
        shoppingCartService.removeItem(principal, uuid, productId);
    }
}
